package me.zhulin.shopapi.enums;

/**
 * Created By Zhu Lin on 3/9/2018.
 */
public interface CodeEnum {
    Integer getCode();

}
